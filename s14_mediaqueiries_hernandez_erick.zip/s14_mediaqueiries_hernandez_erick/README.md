# S14_mediaqueiries_Hernandez_Erick

A Pen created on CodePen.

Original URL: [https://codepen.io/ERICK-HERNANDEZLARRAINZAR/pen/RNrVzLd](https://codepen.io/ERICK-HERNANDEZLARRAINZAR/pen/RNrVzLd).

